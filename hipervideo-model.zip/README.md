hipervideo
==========

Repositorio para testes de Hipervideo

### Versão gulp + sass + vueify

Para rodar servidor, com watchlist e livereload, utilize o gulp

```
$ gulp
```

as tarefas estão no arquivo `gulpfile.js`