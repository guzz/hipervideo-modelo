<style lang="scss">
	
	@import "app/sass/globals";

	%clearfix {
	  zoom: 1; /* IE6&7 */
	  &:before, :after,{
	    content: "";
	    display: table;
	  }
	  &:after {
	    clear: both;
	  }
	}

	#app,
	#app .view,
	#app .view .sidebar {
		height: 100%;
	}

	#full {
		&:-webkit-full-screen {
		  width: 100%;
		  height: 100%;
		  background-color: #333;
		}
	}
	.vue-nav {
		position: relative;
		z-index: 20;
		list-style-type: none;
		margin: 0;
		padding: 0;
		li {
			display: inline;
			margin: 0;
			padding: 0;
			a {
				padding: 10px;
				&:hover {
					background: #eee;
				}
			}
		}
	}

	.view {
		transition: all 0.5s, opacity .3s ease .3s;
		&.is-redes {
			transition: all 0.5s;
			-webkit-transform: translate3d(0,110%,0);
   		-moz-transform: translate3d(0,110%,0);
   		-o-transform: translate3d(0,110%,0);
   		-ms-transform: translate3d(0,110%,0);
   		transform: translate3d(0,110%,0);
   		#app.marco-fechado & {
   			transition: all 0.5s;
				-webkit-transform: translate3d(0,100%,0);
	   		-moz-transform: translate3d(0,100%,0);
	   		-o-transform: translate3d(0,100%,0);
	   		-ms-transform: translate3d(0,100%,0);
	   		transform: translate3d(0,100%,0);
   		}
		}
		&.vie-enter, &.vie-leave {
			opacity: 0;
		}
		&.vie-leave {
			transition-delay: 0;
		}
	}

	body {
	  &.tocando {
	    & header {
	      opacity: 0;
	    }
	    & a {
	      &.hipervideo {
	        opacity: 0;
	      }
	    }
	    .hipVid {
	      opacity: 1;
	    }
	    #video-controls {
	      display: block;
	    }
	  }
	}

	.conteudo {
	  margin: 0 auto;
	  height: 100%;
		width: 100%;
	  @extend %clearfix;
	}

</style>

<template>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<glossario :glossario.sync="glossario" :database="database"><glossario>
	<div id="full" class="view" :is="view" transition="vie" :class="[className]" v-ref:view />
	</div>
</template>

<script>

	module.exports = {
		el: '#app',
		data: {
			database: [],
			db: null,
			view: "",
			className: "",
			glossario: true,
			qualidade: 'baixa',
			acessibilidade: 'normal',
			params: {
				video: null,
				route: null
			}
		},
		watch : {
			qualidade: function (qualidade) {
				this.$broadcast('mudou-qualidade', qualidade);
				document.cookie = "qualidade = " + qualidade;
			},
			acessibilidade: function (val) {
				this.$broadcast('mudou-acess', val);
				document.cookie = "acessibilidade = " + val;
			},
			glossario: function (val) {
				this.$broadcast('glossario-update', val);
			}
		},
		attached: function() {

			switch(getCookie('qualidade')) {
				case '':
					document.cookie = "qualidade=baixa"
					break
				case 'alta':
					this.qualidade = 'alta'
					break
				case 'media':
					this.qualidade = 'media'
					break
				case 'baixa':
					this.qualidade = 'baixa'
					break
			}

			switch(getCookie('acessibilidade')) {
				case '':
					document.cookie = "acessibilidade=normal"
					break
				case 'libras':
					this.acessibilidade = 'libras'
					break
				case 'audio':
					this.acessibilidade = 'audio'
					break
				case 'normal':
					this.acessibilidade = 'normal'
					break
			}

			function getCookie(cname) {
		    var name = cname + "=";
		    var ca = document.cookie.split(';')
		    for(var i=0; i<ca.length; i++) {
	        var c = ca[i]
	        while (c.charAt(0)==' ') c = c.substring(1)
	        if (c.indexOf(name) == 0) return c.substring(name.length,c.length)
		    }
		    return ""
			}

		},
		components: {
			'home-view': require('./views/home-view.vue'),
			'video-view': require('./views/video-view.vue'),
			'glossario': require('./components/redes.vue')
		}
	}

</script>