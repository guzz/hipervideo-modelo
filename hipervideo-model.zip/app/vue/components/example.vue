<style lang="scss">

</style>

<template>
	<p>
		<strong>my content is:</strong><br/>
		<content/>
	</p>
</template>

<script>

	module.exports = {

	}

</script>