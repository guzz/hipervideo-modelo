(function(){
	var _ = require('underscore')
	var Vue = require('vue')
	var Router = require('director').Router
	var app = new Vue(require('./app.vue'))
	Vue.config.debug = true

	// ROUTES

	var routes = {
		'/home' : {
			'/:id': {
				on: function(id) {
					var validation = _.findWhere(app.database,{"id": id})

					if (id === 'glossario' && validation !== undefined) {
						ga('send', 'pageview', '/'+id)
						if(app.$refs.view){
							app.$data.glossario = true
						} else {
							app.$once('home-view-ready',function(){
								app.$data.glossario = true
							})
						}
					} else if(id !== 'glossario' && validation !== undefined) {
						ga('send', 'pageview', '/home/'+id)
						if(app.$refs.view){
							app.$refs.view.fechar()
							app.$refs.view.hiperHome(id)
						} else {
							app.$once('home-view-ready',function(){
								app.$refs.view.fechar()
								app.$refs.view.hiperHome(id)
							})
						}
					} else {
						router.notfound()
					}
				}
			},
			on: function () {
				app.$data.className = 'is-home'
				ga('send', 'pageview', '/home')
				Vue.nextTick(function () {
					app.$data.view = 'home-view'
				})
			}
		},
		'/:id': {
			'/info/:info': {
				on: function(id,info){
					ga('send', 'event', 'EventoInfo', 'open', id + '::info-' + info)
					Vue.nextTick(function () {
						if(app.$.view){
							app.$.view.infoOpen(info)
						} else {
							app.$once('video-view-ready',function(){
								app.$.view.infoOpen(info)
							})
						}
					})
				}
			},
			on: function (id) {
				var validation = _.findWhere(app.database,{"id": id})
				var self = this
				var last_route = app.params.route
				var cur_route = app.params.route = self.getRoute()

				if (app.view === 'video-view' && app.params.video === id && validation !== undefined) {
					ga('send', 'event', 'EventoInfo', 'close', id + '::info-' + last_route)
					
					// conditions
					var last_is_info = last_route.length > 1 && last_route[1] == 'info';
					var current_is_info = cur_route.length > 1 && cur_route[1] == 'info';

					if(last_is_info && !current_is_info){
						app.$.view.infoClose()
					}

					return // prevent transition on the same id

				} else if(validation === undefined){
					router.notfound()
				}

				// force transition

				app.$data.view = ''


				Vue.nextTick(function () {
					ga('send', 'pageview', '/'+id)
					app.$data.db = _.findWhere(app.database,{"id": id})
					app.$data.view = 'video-view'
					app.$data.params.video = id
					app.$data.className = 'is-video-' + id
				})
				
			}
		}
	}

	// DATA: load api folder before router initialization

	var hipervideos_db = ['hipervideo-default']
	var n = 0

	var getDatabase = function (file) {
		var xhr = new XMLHttpRequest()
		xhr.open('GET', '/api/'+file+'.json')
		xhr.onload = function () {
			var db_tmp = JSON.parse(xhr.responseText)
			app.$data.database.push(db_tmp)
			canInit()
		}
		xhr.send()
	}

	var canInit = function () {
		if (n < hipervideos_db.length) {n = n+1}
		else {init()}
	}

	var router = new Router(routes)

	for (var i = 0; i < hipervideos_db.length; i++) {
		getDatabase(hipervideos_db[i])
		if (i === hipervideos_db.length - 1) {init()}
	};

	// ROUTER INIT
	
	function init(){
		router 
			.configure({
				recurse: 'forward',
				notfound: function () {
					router.setRoute('/home')
				}
			})
			.init('/')
	}

})()
